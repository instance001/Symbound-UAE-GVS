SPDX-License-Identifier: AGPL-3.0-or-later

# OUTPUT_NOTICE – Symbound Commons Output Rules
## Applies to All UAE/GVS-Generated Artifacts

This project includes the following system components:

- Universal Analogy Enforcement (UAE)
- Global Vector Sweep (GVS)
- Conceptual Translation Layer (CTL)
- High-Value Vector Scoring and Filtering

These mechanisms generate:
- structural profiles
- CTL reports
- cross-domain analogies
- vector expansions
- application mappings
- feasibility/risk/impact scoring
- conceptual insights
- derivative datasets
- markdown and JSON artifacts

These outputs are NOT user content.
They are programmatically produced system artifacts, and therefore fall under the GNU AGPLv3 License.

## Legal Consequences

1. License Inheritance  
All system-generated UAE/GVS outputs inherit AGPLv3 automatically and irrevocably.

2. No Proprietary Relicensing  
You may not enclose, privatize, close-source, trademark, copyright, or otherwise restrict
any such output.

3. Anti-Patent Guarantee  
All UAE/GVS-generated outputs are automatically considered public disclosures at the time of
generation, making them:
- unpatentable worldwide
- permanent prior art
- impossible to enclose

Any attempt to patent them is invalid and an AGPL violation.

4. Mandatory Pass-through  
Any modified version of this software, hosted locally or over a network, must preserve this Output
Notice verbatim.

5. Global Commons Protection  
This mechanism ensures that all breakthroughs generated via UAE/GVS remain in the public
domain-equivalent commons, accessible to all humans and models forever.
